# The 5 employees: what to paste, what to give them first

Every prompt lives in `projects/NN-<name>.instructions.txt` with the Brand Foundation already inserted. Paste the whole file into the Project's Instructions box. `projects/README-prompts.md` shows the bare prompts with the `[BRAND FOUNDATION]` marker for reference.

## 01 Content Strategist
- **Project name:** `Content Strategist`
- **Packet example (p.5):** "Write me a 60-second TikTok about why most people fail at building a morning routine."
- **First real task:** Write me a 45-second vertical video. Day 1: the 5 Claude Projects I am setting up this week instead of hiring a marketing staff. Screen recording, I narrate. End with the free guide.
- **Status:** run 2026-09-15 as a full Week 1 batch. Output: `content/2026-09-21-week1.md`.

## 02 Researcher
- **Project name:** `Researcher`
- **Packet example (p.6):** "I just watched a video in my niche that got 2M views. The creator listed 5 things in 45 seconds with fast cuts. Why did this work?"
- **First real task:** [Paste the transcript of one veteran-entrepreneur or AI-for-business video that outperformed, plus its view count, length, and format.] Why did this work and what do I test?
- **Operator note:** this employee cannot open TikTok/YouTube/IG links. Paste the transcript, describe the format (length, cuts, on-screen text, hook line), give the view count. Input quality = output quality (packet p.10).
- **Status:** not yet run. Monday job.

## 03 Product Builder
- **Project name:** `Product Builder`
- **Packet example (p.7):** "I want to create a $27 ebook for people who want to start freelancing but have no idea where to begin. Help me build it."
- **First real task:** Build the free guide first. Name is fixed: "The Solo Operator's AI Team: 5 Claude Projects that replace a marketing staff, built in an hour, documented as I go." Skip name and price steps. Credit the Capri packet. Then the $27 to $47 paid playbook it upsells to.
- **Before the first run:** add the five `.instructions.txt` files to this Project's knowledge so the guide describes the real prompts instead of inventing them.
- **Status:** free guide done (`products/free-guide.md`, `products/free-guide-v0.pdf`). Paid playbook: next Thursday job.

## 04 Email Marketer
- **Project name:** `Email Marketer`
- **Packet example (p.8):** "Write a 5-email welcome sequence for someone who just downloaded my free guide on starting a content business."
- **First real task:** Write a 5-email welcome sequence for a veteran who just downloaded my free guide on the 5 Claude Projects that replace a marketing staff. Email 5: ask them to reply with their biggest bottleneck, plus a playbook waitlist link. Swap in the real pitch at launch.
- **Prerequisite:** Kit Free account, guide form, and PDF incentive (checklist decisions 1 to 3). Kit Free has no drip sequences: email 1 is the incentive-delivery email, emails 2 to 5 are Friday broadcasts until the Creator upgrade.
- **Status:** done (`email/welcome-sequence.md`).

## 05 Analyst
- **Project name:** `Analyst`
- **Packet example (p.9):** "My TikTok this month: 45K views, 3.2% like rate, 0.8% save rate, 12 new followers per day. Best video got 18K views. Worst got 200. What do I do?"
- **First real task:** [After 20 posts, paste the real numbers from YouTube Studio, TikTok Analytics, and IG Insights: views, avg watch %, likes, saves, follows, best and worst post.] What do I do this week?
- **Departure from packet (p.9):** the opening line "I am not a numbers person" was replaced with "Give me the numbers straight: rates, deltas, and what changed." Everything else is verbatim.
- **First run:** after 20 posts. Paste real numbers only. Never the packet's sample stats.
