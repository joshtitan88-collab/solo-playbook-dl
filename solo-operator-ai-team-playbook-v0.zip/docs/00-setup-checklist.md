# 00: Setup Checklist (packet pp.3, 4, 10)

## BLUF
Five Claude Projects, one per employee. Each gets its `projects/NN-<name>.instructions.txt` pasted into **Project Instructions**. Brand Foundation is already inside every prompt. Nothing to fill in. About 2 min per project, 10 min total. Every decision below is made; only the pasting is yours.

## Fix first: the existing project is misconfigured vs. the packet
- **Name:** the existing project is called "Content Strategist, Researcher, Product Builder". That is the packet's *example* string (p.4, step 4), not a name. Packet design = 1 project per employee.
- **Instructions:** currently the raw Content Strategist prompt with the Brand Foundation placeholder still unfilled. The employee has no idea who you are.
- **Description:** holds the Brand Foundation *intake* prompt (p.3). One-time regular-chat prompt, not project content. Delete it.
- **Project knowledge:** remove `Your 20 AI Content Team.pdf` from the project after setup. Its last page ("wealth transfer," "life-changing," "1% better") is banned vocabulary sitting in the employee's context.
- **Fix:** rename the project to `Content Strategist`; replace Instructions with `01-content-strategist.instructions.txt`; clear Description; remove the PDF. Then create 4 more.

## Steps per employee (packet p.4; steps 4 and 5 adapted because the Foundation is pre-inserted)
1. Go to claude.ai and log in
2. Click **Projects** in the left sidebar
3. Click **+ New Project** (label may read "New project"; same thing)
4. Name your project: exact name from the table below
5. Find the **Project Instructions** box (in the project's settings/knowledge panel). Open the matching `.instructions.txt`, select all, copy, paste. The packet's "add your Brand Foundation summary" half of this step is already done.
6. Save. Done.

| # | Project name | Paste from | First real task |
|---|---|---|---|
| 01 | `Content Strategist` | projects/01-content-strategist.instructions.txt | Day 1 video: the 5 Projects I am setting up instead of a marketing staff |
| 02 | `Researcher` | projects/02-researcher.instructions.txt | Break down one outperforming video (paste transcript) |
| 03 | `Product Builder` | projects/03-product-builder.instructions.txt | Free guide first (attach the 5 .instructions.txt files to its knowledge), then the paid playbook |
| 04 | `Email Marketer` | projects/04-email-marketer.instructions.txt | 5-email welcome sequence; email 5 = reply ask + playbook waitlist |
| 05 | `Analyst` | projects/05-analyst.instructions.txt | After 20 posts: real numbers from all 3 platforms |

The packet examples (morning routines, freelancing ebook, content-business guide) contradict the Foundation. The first real tasks above replace them. Status: tasks 01, 03, 04 were run 2026-09-15 (see `content/`, `products/`, `email/`).

## Departures from the packet (all deliberate)
- Analyst prompt: "I am not a numbers person" replaced with "Give me the numbers straight: rates, deltas, and what changed."
- Platforms: packet is TikTok-first. Foundation is film once, post to YouTube Shorts (home), TikTok, IG Reels; LinkedIn text for the security audience.
- Credit: the free guide and paid playbook both credit the Capri packet (its terms: share freely, credit kindly). Paid value is what you added, not her prompts.

## Decisions made for you (change if you disagree, otherwise run them)
1. **Email service provider: Kit (formerly ConvertKit), Free plan.** Verified 2026-09-13 on kit.com/pricing (confidence High): up to 10,000 subscribers, unlimited landing pages and forms, automatic opt-in incentive delivery (the guide PDF). What Free does NOT include: automated email sequences; those start on Creator ($33/month). Alternative checked and rejected: MailerLite Free has automations but caps at 250 subscribers and 5 automation steps, which the 6-month list goal outgrows.
2. **How the welcome sequence runs on Free:** all 5 emails are written (`email/welcome-sequence.md`). Email 1 is the Kit incentive-delivery email. Emails 2 to 5 go out as Friday broadcasts to the guide-download tag. Upgrade to Creator and load the 5 emails as a true drip when the list passes 100 or the playbook launches, whichever is first.
3. **Free guide delivery:** `products/free-guide-v0.pdf` uploaded as the Kit form's incentive. Replace `[SCREENSHOT]` placeholders and rebuild with `tools/build_guide_pdf.py` once the 5 Projects exist.
4. **Playbook checkout:** Stripe Payment Link (Stripe account already exists). Waitlist until launch is a second Kit form with its own tag.
5. **Analyst cadence:** first run after 20 posts, not week 1. Sunday slot stays empty until then.

## Weekly rhythm (packet p.10)
| Day | Employee | Job |
|---|---|---|
| Sun | Analyst | Review last week's numbers, set priorities (skip until 20 posts exist) |
| Mon | Researcher | What is trending / working in the niche |
| Tue | Content Strategist | Plan and write the week's content from Researcher output |
| Wed | none | Film, edit, post or schedule. No AI. |
| Thu | Product Builder | Next digital product or offer |
| Fri | Email Marketer | Write or schedule the pitch email to the list |

**One rule (p.10):** "The more specific you are with each employee, the better the output. They perform exactly as well as the context you give them."

## Hidden Trap
The packet's rhythm assumes you *post on Wednesday*. The documented failure mode is building instead of shipping. Sun to Tue produce inputs; if Wednesday does not happen, the other four employees are theater. Second trap: this content system is a new build while the Henry Intel pipeline needs a fresh cold batch. Rule: outreach sends before filming, every week.
