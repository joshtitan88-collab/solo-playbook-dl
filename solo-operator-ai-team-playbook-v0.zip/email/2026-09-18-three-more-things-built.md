# Friday broadcast: Sep 18, 2026

## Send note (delete before loading into Kit)

- Supersedes email/2026-09-15-zero-posts-this-week.md, which a Tuesday run wrote for the same send date. Send this one. That file is marked superseded and stays in the repo for the record.
- Welcome sequence status: none of the Friday broadcasts (Emails 2 to 5) has been queued. README status (Sep 17) still lists the Kit form as not live, so Email 1 has not gone to anyone either.
- Welcome email that sends today: Email 2, "The mistake that makes AI sound like AI." Schedule it as a broadcast to the guide-download tag. With no form live it sends to zero people. Schedule it anyway so the cadence exists the day the form goes up.
- The broadcast below is for subscribers who have finished Email 5. That segment is empty today. Load it as a draft broadcast to the sequence-complete tag, scheduled today. Do not send it to the guide-download tag; that segment is still inside the sequence.
- What changed since the Tuesday draft: sales page copy, Stripe Payment Link copy, and playbook v0 were added to the repo (Sep 16 to 17). The 5 Projects, the Kit form, and the link in bio are still not done. The email names that.
- No numbers outside NUMBERS I CAN CITE. The playbook price is not stated here; the $37 call in the repo is not in the Foundation list yet.
- Placeholder to replace: [WAITLIST LINK].
- Body word count: 192. QA gate: tools/qa_check.py passes.

## Broadcast

**Subject line:** Three more things built. Still zero posts.
**Alt B:** The build list got longer this week
**Alt C:** Zero posts, again, and the deadline is Monday

**Preview text:** The mistake I warn about in every script, done by me, for the second week.

**Body:**

Bottom line: still zero posts. The build list got longer instead. That is the mistake, named twice now, and it is mine.

What got built since Tuesday. A sales page. Stripe checkout copy. A first draft of the playbook. All three point at a product that does not ship until December.

What did not get built. The 5 Claude Projects on claude.ai. The Kit form. The link in bio. Every script written for next week ends on a call to action that goes nowhere.

That is building instead of selling in its purest form: writing the sales page before the thing it sells has a single reader. The order was supposed to be Projects first, form live, first video Monday. I wrote that down on Tuesday and then did the opposite.

Can't verify yet whether anything in the batch works. Nothing has posted, so there is no number to give you.

Monday, Sep 21, video 1 goes up. If it does not, next Friday's email says so, with no excuse attached.

The playbook is where the real numbers land as they come in. Waitlist below. Nothing is charged until it ships.

Josh

**CTA:** Join the playbook waitlist: [WAITLIST LINK]
