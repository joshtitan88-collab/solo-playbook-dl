# Friday broadcast: Sep 18, 2026 (written Tue Sep 15)

SUPERSEDED on 2026-09-18 by email/2026-09-18-three-more-things-built.md. Do not load this version into Kit.

## Send note (delete before loading into Kit)

- Welcome sequence status: none of the Friday broadcasts (Emails 2 to 5) has been queued. Repo email/ holds only welcome-sequence.md. README status says the Kit form is not live, so Email 1 has not gone to anyone either.
- Welcome email that sends this Friday: Email 2, "The mistake that makes AI sound like AI." Schedule it Fri Sep 18 as a broadcast filtered to the guide-download tag. With no form live it sends to zero people. Schedule it anyway so the cadence exists the day the form goes up.
- The broadcast below is for subscribers who have finished Email 5. That segment is empty today. Load it as a draft broadcast to the sequence-complete tag, scheduled Fri Sep 18. Kit sends it to nobody now and to the right people once the tag has members. Do not send it to the guide-download tag; that segment is still inside the sequence.
- Order of work before Friday: Kit form live, Email 1 loaded as the incentive email, Email 2 scheduled, this broadcast drafted. Four things, all in Kit.
- Placeholder to replace: [WAITLIST LINK].
- Timing: this run fired Tuesday, not Friday. File is dated by the run (Sep 15). Send date is Fri Sep 18.

## Broadcast

**Subject line:** Zero posts this week. Here is why.
**Alt B:** The week I built everything and shipped nothing
**Alt C:** Five scripts, one guide, zero posts

**Preview text:** The exact mistake I warn about in the batch, done by me, in week one.

**Body:**

Bottom line: nothing posted this week. Everything got built instead. That is the mistake, and it is mine.

The week in one list. Five video scripts written for Sep 21 to 25. The free guide drafted and rendered. The welcome sequence written for Kit. A first draft of the playbook. Five Claude Projects planned at $20 a month.

What is not done. The five Projects are not built on claude.ai. The Kit form is not live. The link in bio points nowhere. Every piece above ends on a call to action that leads to something that does not exist yet.

That is building instead of selling, the exact habit video 4 warns about. Writing a script that names the mistake is not the same as not making it.

Can't verify yet whether the batch works. Nothing has been posted, so there is no number. Real numbers show up here when I have them, not before.

The order is fixed now. Projects first. Form live. First video up Monday, Sep 21. If it is not, next Friday's email says so.

The playbook is where the numbers land as they come in. Waitlist below. Nothing charged until it ships.

Josh

**CTA:** Join the playbook waitlist: [WAITLIST LINK]
