# Welcome Sequence: The Solo Operator's AI Team (free guide)

## Operator note (delete before loading into Kit)

- Platform: Kit (formerly ConvertKit), Free plan. The Free plan has no automated sequences, so this is delivered in two parts.
- Email 1 is the incentive-delivery email on the guide-download form. It carries the PDF via [GUIDE DOWNLOAD LINK] and sends on signup.
- Emails 2 to 5 go out as Friday broadcasts to the guide-download tag, one per week, in order. Filter each broadcast to subscribers tagged in the prior week so nobody gets Email 4 before Email 2. When the Creator upgrade happens, load all five into a Visual Automation as a drip with a 7-day delay between sends and retire the manual broadcasts.
- Placeholders to replace: [GUIDE DOWNLOAD LINK], [WAITLIST LINK], [YOUTUBE CHANNEL LINK], [LINKEDIN LINK]. Put [LINKEDIN LINK] in the Kit email template footer, not in body copy, so every email keeps one CTA.
- Email 5 is the pre-launch version. Swap in the real playbook pitch, price, and buy link at launch (target: Dec 31). Until then it points to the waitlist only.
- Subject line A is the default. B and C are for A/B tests once the list is big enough to read a result. Do not report open rates in content until they are verified.
- Every number in these emails comes from the Brand Foundation. Do not add any.

---

## Email 1: The guide, and the one thing to do first

**Send:** On signup (Kit incentive-delivery email)

**Subject line:** Your guide is here. Build the foundation first.
**Alt B:** The guide, plus the one thing to do before you open it
**Alt C:** The Solo Operator's AI Team (download inside)

**Preview text:** Download link inside. Do the Brand Foundation before you touch a Project.

**Body:**

Bottom line: the guide is below. Before you build any of the 5 Projects, write your Brand Foundation. Section 4 of the guide explains why. Skip it and the AI writes like the AI.

Here is who I am and who I am not.

I am Josh Henry. 8 years Army. 3 businesses. 0 employees. I am replacing a marketing staff with 5 Claude Projects on a $20 a month plan, and I am documenting it as I go. That is the whole guide.

I am not a guru. No course, no coaching, no results I have not had.

What to expect from these emails: one a week, on Fridays. Each one covers one mistake I made or one thing that worked, with the real number attached. When I do not have a number yet, I say "can't verify yet."

Next week: the Brand Foundation mistake almost everyone makes in the first ten minutes.

One more thing. If this landed in promotions or spam, reply to it. That tells your inbox I am not junk, and I read every reply.

Download the guide. Do the foundation. Then build.

Josh

**CTA:** Download the guide: [GUIDE DOWNLOAD LINK]

---

## Email 2: The Brand Foundation mistake

**Send:** Friday broadcast, week 1

**Subject line:** The mistake that makes AI sound like AI
**Alt B:** Why your Claude Project writes like a stranger
**Alt C:** 6 questions before you paste a single prompt

**Preview text:** Most people paste the prompts and skip the foundation. Here is what that costs.

**Body:**

Bottom line: paste the prompts without a Brand Foundation and the AI writes in its own voice, not yours. Everything downstream sounds like everything else online.

Paste the Content Strategist prompt with no foundation and the first script comes back clean, confident, and not yours. It hedges. It uses words you would never say. You gave it a job and no identity.

The fix is the Brand Foundation. It is 6 questions, answered in plain language, pasted at the top of every Project. It is the reason all 5 of mine sound like one person.

The 6 questions:

1. What do you make content about?
2. Who is it for? Be specific. Age, stage, what they will not tolerate.
3. Where do you post?
4. What do you sell, or want to sell?
5. What are your content goals for the next 6 months?
6. How do you talk? Tone, words you use, words you ban.

Question 6 does the most work. My banned list is longer than my approved list.

Answer question 1 in one line and reply with it. I read every reply, and it tells me who is actually on this list.

Josh

**CTA:** Reply to this email with your one-line answer to question 1.

---

## Email 3: The AI does not post for you

**Send:** Friday broadcast, week 2

**Subject line:** The AI does not post for you
**Alt B:** Building instead of shipping (my failure mode)
**Alt C:** The rule I use to stop tinkering

**Preview text:** 5 Projects, built in under an hour. Then the part nobody automates.

**Body:**

Bottom line: the AI team writes. It does not post, and it does not call anyone. That part is still you, and it is the part that fails.

The Content Strategist can draft a week of scripts on Tuesday. Whether anything is filmed and posted by Wednesday is on me. Wednesday is the whole system.

Here is my failure mode, stated plainly. I like building. Give me a new Project to set up, an automation to wire, a prompt to tighten, and I will spend a Wednesday on it. It feels like work. It produces nothing a customer sees.

Building instead of shipping is avoidance wearing a work shirt.

So I made a rule. Outreach and posting come before building. Every day. If a post is not up and an outreach message is not sent, I do not open a Project to tinker. The 5 Projects took under an hour to set up. They are not the bottleneck. I am.

The video on this is on the channel: what the team hands me, what I still do by hand, and where the day goes. Screen on, no theory.

If you build instead of sell, you already know it. Watch the video, then post something before you touch a prompt.

Josh

**CTA:** Watch this week's video: [YOUTUBE CHANNEL LINK]

---

## Email 4: What a stranger can find on your business

**Send:** Friday broadcast, week 3

**Subject line:** What a stranger can find on your business in an afternoon
**Alt B:** 4 things I check before I ever talk to an owner
**Alt C:** Anyone can send email as your business. Here is the check.

**Preview text:** Email authentication, exposed logins, staff posts, breach dumps. Fix or ignore.

**Body:**

Bottom line: a stranger with a laptop and an afternoon can learn more about your business than you think. An external check looks at 4 things first.

1. Email authentication. SPF, DKIM, and DMARC are three DNS records that say which servers may send mail as your domain. Missing or wrong, anyone can send invoices as you. Fix: a few DNS records and a monitoring window. Ignore: a client pays a fake invoice with your name on it.

2. Exposed logins and admin panels. Remote desktop, camera feeds, a forgotten admin page, reachable from the internet. Fix: close or gate them. Ignore: the front door is open and you do not know it.

3. What staff post publicly. Badge photos, office layouts, vendor names, vacation dates. Fix: one conversation and a written policy. Ignore: a scammer has the script for a convincing phone call.

4. Credentials in breach dumps. Old passwords tied to your domain, reused on current accounts. Fix: rotate them and turn on MFA. Ignore: someone logs in as you without breaking anything.

This is the Exposure Audit. $497 if you want it done for you. Not required.

Start with number 1 yourself, today. Search "DMARC record checker" and use MXToolbox or any free one. Type your domain. No record found means that is your first fix.

Josh

**CTA:** Check your domain's DMARC record now: https://mxtoolbox.com/dmarc.aspx (free)

---

## Email 5: One line from you

**Send:** Friday broadcast, week 4

**Subject line:** One line from you, one promise from me
**Alt B:** What is the bottleneck right now?
**Alt C:** The playbook waitlist is open

**Preview text:** Reply with your biggest bottleneck. Then the playbook: $27 to $47, ships by Dec 31.

**Body:**

Bottom line: I want one line from you, then I will tell you what is coming.

Reply to this email with your biggest bottleneck right now. One line. Not the nice version. The thing that is stopping you from posting, selling, or finishing.

I ask because future emails and the playbook get written from those replies, not from what I guess you need. The pattern in my own week is building instead of selling. If yours is different, I need to know.

Now the promise.

The free guide is the setup: 5 Projects, $20 a month, under an hour. The playbook is what I added on top of Jianna Capri's free packet, which the base prompts come from: the Brand Foundation method, my automations, screen recordings of every Project in use, and the real numbers as they come in. Any number I do not have yet will say "can't verify yet" until I do.

Price: $27 to $47. Ships by Dec 31. The waitlist gets first notice. Nothing is charged until it ships.

Reply with the bottleneck. Then get on the list.

Josh

**CTA:** Join the playbook waitlist: [WAITLIST LINK]
