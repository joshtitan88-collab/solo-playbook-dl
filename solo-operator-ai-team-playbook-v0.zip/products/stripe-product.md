# Stripe Payment Link: The Solo Operator's AI Team: Playbook

Product copy v0. Written 2026-09-17 in the Product Builder slot. Not live. Nothing gets created in Stripe until there is a file to deliver. This is the exact text for each Stripe field plus the settings, so launch day is a paste job, not a writing job.

Every number in this file is from NUMBERS I CAN CITE plus the $37 price. Counts of what is inside the download describe the product, not results.

---

## Bottom line

One product, one price, one Payment Link. $37 one-time. The link collects an email, charges the card, and sends the buyer to a download page. Stripe takes the money. It does not send the file. The download page and the buyer tag in Kit are the delivery, and both exist before the link goes live or the link does not go live.

---

## Stripe fields, paste as written

### Product name

The Solo Operator's AI Team: Playbook

### Product description (shows on the checkout page)

Five Claude Projects do my marketing for $20/month. The prompts are free. This is what I built on top so the output ships every week: the Brand Foundation method with my own document as the worked example, the QA gate script, the hand-off map and weekly checklist, the file and git conventions, screen recordings of every build step on my real account, four weeks of batch templates, and my numbers with dates as they come in. Any recording not finished at launch is listed as missing inside the download, not hidden. Every future version included at no charge. Written by a solo owner with 8 years Army, 3 businesses, 0 employees, and 1 security client. No income claims.

### Statement descriptor (what the buyer sees on the card statement)

HENRY INTEL PLAYBOOK

Stripe caps this field short and strips some characters. Check the limit in the dashboard before saving. If the Stripe account is registered under a different name, the descriptor has to be a name the buyer will recognize from the sales page, or the charge gets disputed as unknown.

### Price

$37.00 USD. One-time. No subscription, no trial, no coupon at launch. The v0 price is the discount.

### Image

None at launch. If one gets added later: the title in plain text on a solid background. No stock photo, no badge, no laptop on a desk.

---

## Payment Link settings

1. Collect email: on. The email is the delivery address and the Kit tag key.
2. Collect shipping address: off. Collect phone: off. Fewer fields, fewer abandoned checkouts, and there is nothing to ship.
3. Adjustable quantity: off. One copy per buyer.
4. Promotion codes: off at launch.
5. After payment: redirect to the download page. [DOWNLOAD PAGE URL]. Not the default Stripe confirmation screen.
6. Receipts: on, sent by Stripe to the buyer email.
7. Custom fields: none. The reply ask stays in email, not at checkout.
8. Policies: refund line linked or stated. [REFUND LINE: same text as the sales page. Not decided yet.]
9. Tax: a decision, not a setting. Sales tax on digital downloads varies by state and I am not the one to say what applies here. Can't verify. Decide before the link goes live: Stripe Tax on, or accept the exposure and say so in the ledger.

---

## Confirmation text (if the download page is not ready)

Stripe can show a message instead of a redirect. Use this only if the page is not live on launch day, and swap to the redirect the day it is.

Paid. The download link goes to the email you just entered. Not there by tomorrow: reply to the receipt and I send it by hand. Every future version of the playbook comes to the same address at no charge.

---

## Delivery: what the link cannot do

Bottom line: a Payment Link is a cash register. Three pieces turn the charge into a product, and all three get built before launch.

1. The download page. One page, unlisted, not indexed. Holds the playbook PDF, the gate script, the recording links, and one line stating that v1 arrives at no charge. Its URL is the redirect above.
2. The buyer tag in Kit. Every buyer email gets the tag playbook-buyer. This tag is the v1 promise: the v1 email goes to the tag with the new link. Kit offers a Stripe connection on some plans. Can't verify which plan on the day you read this. The manual version works on every plan: export paid emails from Stripe, tag them in Kit, once a day for the first week, then weekly.
3. The buyer email from Kit. Stripe's receipt goes out on its own. A Kit email to the playbook-buyer tag carries the download link a second time, so the buyer has it in two places and the redirect page going down does not lose the sale.

---

## What breaks

The trap is the gap between the card charge and the file. A buyer who paid $37, got a Stripe receipt, and found no file is a refund and a public complaint on the same day. The causes are boring: redirect page down, tag missed on the manual export, Kit email in spam.

The fix is redundancy, not hope. The download link lives in three places: the redirect, the Kit email, and the reply path on the receipt. Test all three with a live purchase before the waitlist email goes out.

Second trap: the v1 promise. It is on the sales page and in the checkout description. If the buyer tag is not built on day one, there is no list of who was promised what, and v1 either goes to nobody or to everybody. Build the tag before the first sale, not after.

---

## Launch-day order

1. Refund line decided and written on the sales page and in field 8 above.
2. Download page live. Tested in a fresh browser with no login.
3. Kit: playbook-buyer tag created. The v1 promise written in the tag description so it is not forgotten.
4. Stripe: product created with the text above. Price $37. Payment Link created. Redirect set. Test mode first.
5. One live purchase at $37 from a card that is not the business card. Check: redirect landed, email captured, receipt arrived, tag applied. Refund it from the dashboard.
6. Sales page: swap [WAITLIST LINK] for the Payment Link. Delete the pre-launch block.
7. Waitlist email. One link. The launch is the email, not the page.

---

## Page notes for Josh

1. The refund line is still the hole. It blocks field 8 here and the sales page. One sentence. Decide it.
2. Statement descriptor assumes the Stripe account is under Henry Intel. If it is personal, change it to JOSH HENRY PLAYBOOK.
3. The download page needs a home. Options in order: a page on the same domain as the sales page, a Kit landing page, an unlisted Google Drive folder as the fallback. Pick one and it becomes [DOWNLOAD PAGE URL] everywhere.
4. Run tools/qa_check.py on this file after every edit. It passed on 2026-09-17.
