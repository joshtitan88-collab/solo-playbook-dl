# The Solo Operator's AI Team: Playbook

Draft v0. Written 2026-09-15 in the Product Builder slot. Not for sale in this state.

What this file is: the full first draft of the paid playbook the free guide points to. Every square bracket is a hole on purpose. [SCREEN RECORDING] means a clip gets recorded on my real account before launch. [DATA] means a number goes there once it is verified and dated, and not before. Nothing in this draft claims a result I have not had.

How to read it: sections 1 and 2 are the Product Builder's market check and outline. Sections 3 through 8 are the playbook itself, written out. Sections 9 through 12 are names, price, what is missing, and credit.

---

## 1. Market check

Bottom line: can't verify that anyone will pay for this. Nobody has bought it, because it does not exist. The waitlist count is [DATA: waitlist sign-ups by date, from the Kit waitlist tag]. Prompt packs are a crowded shelf and most of them are free, including the one these prompts come from. A paid prompt pack is dead on arrival and I am not building one. The narrower question is whether a person who built the five Projects from the free guide will pay $27 to $47 for the glue: the Brand Foundation method in full, the file conventions, the gate script, the recordings, and my numbers as they arrive with dates. I do not know. The test is cheap and it is already set up: the waitlist form, the reply ask in welcome email 5, and one launch. Before launch, two signals get recorded here: [DATA: waitlist count on launch day] and [DATA: number of email 5 replies naming a bottleneck this playbook covers]. If both are near zero, the product is a video series, not a paid download, and the draft gets shelved.

Who buys it, if anyone: the same person the videos are for. Veterans and transitioning service members, 28 to 45, who want to own something instead of taking a W-2. Two stages, about to start or already running a business alone and stuck. The buyer is the second stage. They downloaded the guide, built at least one Project, and hit the part where good output sits in a chat window and never becomes a post. A second buyer might exist: non-veteran solo owners who find me through LinkedIn, mostly Georgia practice owners. They come for security and the playbook is a side purchase at most. Can't verify that either. Who does not buy: anyone who wants it done for them, anyone who will not film on Wednesday, and anyone shopping for a big-income-with-AI promise. This playbook says out loud that I have 1 security client and no content numbers yet. That filters hard. Good.

---

## 2. Outline

Bottom line: six parts. The prompts are not one of them, because the prompts are free.

Part 1. What you paid for. The line between the free guide, the Capri packet, and this playbook. One table.

Part 2. The Brand Foundation method in depth. The intake prompt. The six questions with my answers as the worked example. The edit pass from voice dump to document. The NUMBERS I CAN CITE rule. The banned-word list method. The QA gate script, explained line by line. Inserting the Foundation into the five prompts.

Part 3. The automations between the five Projects. The hand-off map. The weekly rhythm as a checklist. File conventions. The git repo as the record. The gate in the loop. Scheduled reminders. Project knowledge files.

Part 4. Screen recordings. An index of every clip, one per build step, all recorded on my real account.

Part 5. The real numbers. Empty in v0. The frames are built and each says what fills it and when.

Part 6. The first four weeks of content as templates. Week 1 summarized as a reusable structure. Weeks 2 through 4 as fill-in batches with a theme, a pillar mix, and topic slots.

Then: names, price, what is not in this version, credit.

---

## 3. Part 1: What you paid for

Bottom line: the prompts are free. Jianna Capri wrote them, gave them away, and asked for credit. The free guide gives you the prompts, the marker method, the schedule, and the failure list. This playbook is what I built on top so the output turns into posts, emails, and a product every week without me holding it together by hand.

| Piece | Capri packet (free) | The free guide (free) | This playbook (paid) |
|---|---|---|---|
| The five employee prompts | Yes | Yes, with the [BRAND FOUNDATION] marker | Referenced, not resold |
| The intake prompt | Yes | Yes | Yes, plus the full worked example |
| The six questions | Yes | Yes, with one line each | Yes, with my answers and the edit pass |
| NUMBERS I CAN CITE rule | No | The rule and why | How to build, maintain, and retire the list |
| Banned-word list | No | Mentioned | The method for building yours |
| QA gate script | No | No | Yes, with the code and how to run it |
| Hand-off between Projects | No | The day-per-employee schedule | The map, the checklist, the files, the reminders |
| File conventions and git | No | No | Yes |
| Screen recordings | No | Screenshots | One clip per build step |
| My numbers with dates | No | The verified list | The frames, filled as data arrives |
| Four weeks of content templates | No | No | Yes |

If you only want the prompts, close this and go get the packet. It is free and it is good. The credit section at the end has the link.

---

## 4. Part 2: The Brand Foundation method in depth

Bottom line: the Brand Foundation is one page that gets pasted into every Project. It does more work than all five prompts combined. The free guide gave you the method in a page. This part gives you the whole thing: the intake, my answers, the edit pass, the two rules that keep the output honest, and the script that enforces them.

### 2.1 Why the document beats the prompt

Every Project has a different job. The voice has to be the same across all of them. If the voice lives in the prompts, you maintain it in five places and they drift. If it lives in one document, you edit once and rebuild the five instruction files. When output sounds wrong, I do not touch the prompt. I fix the document. That is the whole design.

### 2.2 The intake prompt

Open a regular Claude chat. Not a Project. Paste this, exactly as written:

> I need your help figuring out what I am building so I can set up my AI team. Ask me questions one at a time about: what I create content about, who my audience is (be specific), what platforms I post on, what I am selling or want to sell, what my content goals are for the next 6 months, and how I talk (my tone, my vibe, words I use or avoid). After I answer everything, write me a short Brand Foundation summary I can paste into other AI prompts. Keep it clear and specific. You can voice dump if you prefer. Start with the first question now.

Then:

1. Answer one question at a time. Do not answer ahead.
2. Voice dump. Use dictation if you have it. Long, messy, specific. Names, prices, dates, grudges.
3. When it hands you the summary, do not paste it anywhere yet. Save it as a file called brand-foundation.md. The edit pass in 2.4 comes first.

[SCREEN RECORDING 01: the intake prompt pasted into a fresh chat, the first question arriving, my first answer dictated in full, no cuts]

### 2.3 The six questions, with my answers

These are my answers as they ended up in the document, not the transcript of the voice dump. The dump is in recording 01. The point of showing them is the level of detail. Vague answers produce a chatbot. These produce me.

Question 1. What do you create content about?

Bad answer: "AI and business." That gets you listicles.

My answer: a veteran building multiple businesses with AI instead of staff. Four pillars. One, the AI team and exactly how it is set up: prompts, Projects, automations, local AI. Two, security and OSINT for small business owners: what is exposed, what it costs, how to fix it. Three, solo business ops: pricing, outreach, and the avoidance habit that kills momentum, building instead of selling. Four, the vet-to-owner path: what discipline transfers, what mindset does not, what nobody tells you.

What it does: gives every Project a way to reject a topic. If a request is not inside one of four pillars, the Content Strategist can say so instead of writing it anyway.

Question 2. Who is the audience?

Bad answer: "Small business owners."

My answer, primary: veterans and transitioning service members, 28 to 45, who want to own something instead of taking a W-2. Two stages: about to start, or running a small business alone and stuck. They have discipline and hate hype. They will not tolerate fluff, cheerleading, or mindset content with no steps. They trust someone who shows the actual screen and the actual number. Secondary, LinkedIn: small business and medical or legal practice owners in Georgia who buy security services. On LinkedIn, drop the vet-to-vet framing and write owner-to-owner. LinkedIn gets pillar 2 and pillar 3 only. When a topic is pillar 2 or 3, also produce a LinkedIn text version.

What it does: two audiences, two framings, and a rule for when each applies. That last sentence is why one prompt can hand me a video script and a LinkedIn post from the same topic without being asked twice.

Question 3. What platforms, what format?

My answer: film once, vertical, 30 to 60 seconds, face on camera or screen recording. Same clip to YouTube Shorts (home base, long-form walkthroughs later), TikTok, and Instagram Reels. LinkedIn gets text posts for the security audience.

What it does: "film once" is a production constraint. The Content Strategist has to write a script that works with no platform-specific edits. The 30 to 60 second window sets the script length before I ask.

Question 4. What do you sell?

My answer: free, the guide. Entry, the $27 to $47 playbook. Security offers, sold mainly through LinkedIn and direct outreach, mentioned in video when relevant, never pitched cold: Email Authentication Fix at $850 one-time plus $150/month monitoring. Exposure Audit at $497 one-time. Exposure Monitoring at $497, $747, or $997 per month by business size. Penetration testing and security consulting by SOW. Then one line: other offers exist, only pitch these in content.

What it does: prices in the document mean the Projects never invent a price and never write "DM me for pricing." The "never pitch cold" line keeps the Email Marketer from turning every email into a sales letter.

Question 5. Content goals for the next six months?

My answer, and these are targets, not results: post at least three times a week, five as the target, no gap longer than three days. 200 email subscribers from the free guide by March 31, 2027. Playbook launched by December 31, 2026, 25 copies sold by March 31. 10 qualified security leads from LinkedIn content by March 31, leads not closes. Until launch, every email points to the waitlist, not a product.

What it does: a date on every goal. That is what the Analyst measures against on Sundays. When a target is hit, it moves to NUMBERS I CAN CITE with the date. When one is missed, that goes on camera too.

Question 6. How do you talk?

My answer: BLUF is structure, not a spoken word. Bottom line first, always. Short sentences. Blunt, directive, peer-to-peer. Military framing without the costume: no skulls, no theatrics. Say the number, from the verified list. Name the mistake. Show the screen. Dry humor, never at the audience's expense. Four signature phrases, at most one per piece, product names excluded; one of them is "the actual steps" and the rest are in HOW I TALK in my document. A never-use list, covered in 2.6. No hedging on opinions. On facts I cannot verify, say "can't verify" instead of softening. Never fabricate results, numbers, or client stories.

What it does: everything after "short sentences" is a rule a script can check or an editor can spot in one read. That is deliberate. "Authentic and engaging" is not a rule. "No exclamation points" is.

### 2.4 From voice dump to document: the edit pass

Bottom line: Claude's summary is a draft. Four passes turn it into the document.

1. Cut every line that is not true today. "Helping thousands of veterans" goes. "1 client" stays.
2. Add a WHO I AM block at the top. Name, background, businesses, headcount, and what you are doing right now in one sentence. Mine: 8 years Army, three businesses, 0 employees, building an AI team and documenting it from day one.
3. Add NUMBERS I CAN CITE. Section 2.5.
4. Rewrite HOW I TALK until every line is checkable. Section 2.6 for the never-use list.

Then read it aloud once. Any line you would not say to a peer at a table gets cut.

[SCREEN RECORDING 02: the raw summary on the left, the edited brand-foundation.md on the right, the four passes applied live]

### 2.5 The NUMBERS I CAN CITE rule

Bottom line: the model will invent a statistic if you let it. The fix is a short list of numbers you can prove, plus one instruction about what to do when a number is not on it.

The heading goes in the Foundation, verbatim: NUMBERS I CAN CITE (verified; use these, invent nothing).

What qualifies:

- A number you could show on screen right now. A dashboard, a bank record, a signed SOW, a DD-214.
- Your own prices.
- Counts about you: years served, businesses owned, employees.

What does not qualify:

- Anything you read somewhere. Industry stats, platform averages, "most creators."
- Anything from the packet's examples. Those are format samples, not data.
- Goals. Goals live in the goals section with a date. They are not citable until hit.
- Client results you have not verified and cannot anonymize cleanly.

My list, today, in full:

> 8 years Army. 3 businesses. 0 employees.
> $20/month: the entire cost of the AI team.
> 5 Projects, set up in under an hour.
> 1 healthcare-practice security client, anonymized; first engagement paid $2,000+.
> The offer prices above.
> Anything else: say "can't verify" or leave it out. No other client stories exist yet.

That last line is the rule. It tells the model what to output when it does not have a number: the words "can't verify," not a plausible guess.

Maintaining the list:

1. Adding a number: it goes in with the date it was verified and where it came from. "200 subscribers" becomes "200 subscribers (Kit dashboard, 2027-03-31)." The date is part of the number.
2. Retiring a number: when a number stops being true, it comes out the same day. "0 employees" leaves the day I hire.
3. Rebuild: every change to the list means the five instruction files get rebuilt and re-pasted. Section 2.8.
4. Manual check before shipping: read every digit in the piece against the list. The gate script in 2.7 does not do this. You do.

[SCREEN RECORDING 03: the Content Strategist asked for a stat that is not on the list, and the reply saying "can't verify" instead of inventing one]

### 2.6 The banned-word list method

Bottom line: you cannot describe your voice into a model. You can tell it what never to say, and that gets you most of the way.

The list has four categories. Build yours by category.

1. Default AI vocabulary. Run any prompt with no Foundation ten times. Every word that shows up in the output that you have never said out loud goes on the list. You will find the same handful every time. You know them when you see them.
2. Hype. The vocabulary of income screenshots and course launches. If a phrase would sit comfortably on a "how I make six figures" thumbnail, it goes on the list.
3. Corporate filler and cheerful closers. The openers that thank you for the question, the sentences that note how important something is, the sign-offs that hope this helped. The whole category, not individual words.
4. Punctuation and glyphs. Mine: no em dashes, no exclamation points, no emojis. All three are the easiest tells of unedited AI output and all three are trivial for a script to catch.

Then the opposite list, and this one is the trap. Words you actually use. The instinct is to tell the model to use them. It will use them in every sentence. So the rule in my Foundation is: at most one per piece, product names excluded. Four phrases, capped. The gate counts them.

Keep the list short enough to hold in your head. If it passes twenty entries, you are banning words you never had a problem with. My full list is in the HOW I TALK block of brand-foundation.md and, as code, in the BANNED array of the gate script. I am not repeating it in the body of this playbook, because the gate would fail this file if I did. That is the gate working.

### 2.7 The QA gate script

Bottom line: one Python file, one command, exit 0 or it does not ship. It catches vocabulary and punctuation. It does not catch tone or fabricated numbers. Those are yours.

The file is tools/qa_check.py and it ships with this playbook. The skeleton, with the word lists replaced by placeholders so this file passes its own gate:

```
import re, sys

BANNED = [ ...your never-use list, lowercase, phrases allowed... ]
RESTRICTED = [ ...your signature phrases, max 1 per section... ]
PRODUCT_NAME = "the solo operator's ai team"

def check(path):
    raw = open(path, encoding='utf-8').read()
    # blockquotes are quoted source text, not new copy
    s = '\n'.join(l for l in raw.splitlines() if not l.lstrip().startswith('>'))
    low = s.lower().replace(PRODUCT_NAME, '')
    problems = []
    if '\u2014' in s or '\u2013' in s: problems.append('em/en dash')
    if '!' in s: problems.append('exclamation point')
    if any(ord(c) > 0x2000 and c not in '\u2014\u2013\u2018\u2019\u201c\u201d' for c in s):
        problems.append('emoji/non-text glyph')
    for b in BANNED:
        n = len(re.findall(r'\b' + re.escape(b) + r'\b', low))
        if n: problems.append(f'banned "{b}" x{n}')
    for sec in re.split(r'^## ', low, flags=re.M):
        hits = sum(len(re.findall(r'\b' + re.escape(w) + r'\b', sec)) for w in RESTRICTED)
        if hits > 1:
            problems.append(f'restricted words x{hits} in one section')
    return problems

if __name__ == '__main__':
    bad = 0
    for p in sys.argv[1:]:
        probs = check(p)
        print(('FAIL ' if probs else 'ok   ') + p)
        for x in probs: print('     -', x)
        bad += bool(probs)
    sys.exit(1 if bad else 0)
```

What each block does:

- Blockquote skip. Lines starting with ">" are quoted source, like the Foundation excerpts above, and are not checked. Do not abuse this. It is for quoting, not for hiding.
- Product name strip. Your product name may contain one of your signature words. Mine does. The strip removes it before counting so the title does not burn your one allowed use.
- Dash and exclamation checks. Character matches. No exceptions.
- Glyph check. Anything above a code point that plain text needs, except the four curly quote marks. This catches emojis and the arrows and bullets that copy in from other tools.
- Banned words. Whole-word matches, case-insensitive, with a count. A phrase like a three-word closer works because the regex escapes the spaces.
- Restricted words. The file is split on level-2 headers. Each chunk gets a count across all signature phrases together. More than one in a chunk fails. A single video script is one chunk. A batch file with five videos is five chunks.

How to use it:

1. Install Python 3 if the machine does not have it. On Windows the command is py instead of python3.
2. From the repo folder: python3 tools/qa_check.py content/*.md email/*.md products/*.md
3. Read the output. ok means clean. FAIL lists each problem with a count.
4. Fix the file, not the script. The only edits the script gets are new entries in the lists, and each of those is a Foundation change first.

What it cannot do, so you do it by hand:

- Tone. A file can pass with zero banned words and still sound like a marketing department. The read-aloud test is the check.
- Numbers. It does not know your NUMBERS I CAN CITE list. A number whitelist is on the v1 list in section 11.
- Claims. "I did this for a client" passes the gate. Whether it is true is on you.

[SCREEN RECORDING 04: the gate run on a Week 1 batch, one FAIL on purpose, the fix, the re-run to ok]

### 2.8 Inserting the Foundation into the five prompts

Bottom line: the Foundation is pasted into each prompt at the [BRAND FOUNDATION] marker, the result is saved as a file per employee, and that file is what gets pasted into the Project. Never paste the Foundation into a Project by hand five times.

Steps:

1. projects/README-prompts.md holds the five bare prompts with the marker on line 2 of each.
2. For each prompt, replace the marker line with the full contents of brand-foundation.md. Save as projects/01-content-strategist.instructions.txt, 02-researcher, 03-product-builder, 04-email-marketer, 05-analyst.
3. Open the Project on claude.ai. Open the instructions panel. Select all, paste the matching file, save.
4. Start a chat in the Project and type: "Confirm you have my Brand Foundation. Quote my audience back to me in one line." If it quotes you, it loaded.
5. Any time brand-foundation.md changes, repeat steps 2 through 4 for all five. This is the one chore that does not shrink. It takes a few minutes and it is the price of one source of truth.

Do the replacement in a text editor, or with a five-line script if you have one. Either way the instruction files are generated from the Foundation, never edited directly.

[SCREEN RECORDING 05: rebuilding the five instruction files after one line changes in the Foundation, then re-pasting one of them into its Project and running the confirmation test]

---

## 5. Part 3: The automations between the five Projects

Bottom line: at $20/month there is no API and no glue code between Projects. The automation is a set of conventions, one script, and reminders. Each employee's output is a file. The next employee's input is that file. That is enough, and it is honest about what the tool is.

### 3.1 The hand-off map

| Day | Employee | Input it needs | Output file | Who consumes it next |
|---|---|---|---|---|
| Sun | Analyst | This week's platform numbers, pasted as the dashboard shows them, plus last week's file | numbers/YYYY-MM-DD-analyst.md, and weekly-numbers.txt updated in Project knowledge | Content Strategist (Tue) gets the priority line |
| Mon | Researcher | Three pieces from the niche: hook, format, two lines each | Pasted into the week's content file under "Inputs" | Content Strategist (Tue) gets the one test |
| Tue | Content Strategist | The Inputs block, the week's topics | content/YYYY-MM-DD-weekN.md | You (Wed) film from it. Email Marketer (Fri) reads it |
| Wed | none | The content file | Posted clips, links pasted back into the content file | Email Marketer (Fri), Analyst (Sun) |
| Thu | Product Builder | The product's current draft file | products/<name>-vN.md | Email Marketer (Fri) gets the "what shipped" line |
| Fri | Email Marketer | The content file, the product line, the Inputs block | email/YYYY-MM-DD-<subject>.md | The list. Analyst (Sun) gets the open and click numbers |

The YYYY-MM-DD in a content file is the Monday it posts. Every other file uses the day it was written.

### 3.2 The weekly rhythm as a checklist

Bottom line: copy this into a note. Check the boxes. The only day that produces anything the audience sees is Wednesday, and outreach for the security business sends before the camera comes out.

Sunday, Analyst (skip until 20 posts exist; paste zeros with the date until then)

- [ ] Open YouTube Studio, TikTok Analytics, IG Insights, Kit. Copy the week's numbers as shown.
- [ ] Open the Analyst Project. Paste the numbers with the date and last week's numbers.
- [ ] Save the reply to numbers/YYYY-MM-DD-analyst.md.
- [ ] Update weekly-numbers.txt and re-upload it to the Analyst's Project knowledge.
- [ ] Copy the "Your priority this week:" line. It goes at the top of next week's content file.
- [ ] Commit.

Monday, Researcher

- [ ] Pick the three best pieces you saw in the niche this weekend. Paste hook, format, two lines each.
- [ ] Ask what they have in common and what one thing to test this week.
- [ ] Create content/YYYY-MM-DD-weekN.md for next Monday's date. First header: "## Inputs". Paste the Analyst priority line and the Researcher test under it.
- [ ] Commit.

Tuesday, Content Strategist

- [ ] Open the Content Strategist. Paste the Inputs block and the week's five topics, one per pillar where possible.
- [ ] Get the batch: hooks, scripts, captions, hashtags, alternative angle, and a LinkedIn version for anything in pillar 2 or 3.
- [ ] Paste the batch into the content file under the Inputs block.
- [ ] Edit until it sounds like you. Mark every line you would never say. Feed those back with "never write like this."
- [ ] Run the gate. Fix until ok.
- [ ] Commit.

Wednesday, film and post. No AI.

- [ ] Security outreach sends first. Then the camera.
- [ ] Film all five in one sitting, face-on-camera clips together, screen recordings together.
- [ ] Cut. Post one per day, or schedule them.
- [ ] Paste each posted link back into the content file next to its video.
- [ ] Commit.

Thursday, Product Builder

- [ ] Open the Product Builder. One session on the current product file. Outline, one section, or pricing. Ship a piece of it.
- [ ] Save as the next version in products/.
- [ ] Run the gate on it.
- [ ] Commit.

Friday, Email Marketer

- [ ] Open the Email Marketer. Give it the content file, the Thursday line, and one thing you learned this week.
- [ ] One email. One call to action. Waitlist until the playbook exists.
- [ ] Save to email/. Run the gate. Send or schedule it in Kit.
- [ ] Commit.

Any week the Wednesday box stays empty, the other five days were theater. Film first if you have to.

### 3.3 File conventions

Bottom line: one folder, fixed names, one file per week for content. Anything the AI wrote lives here and nowhere else. Chat history is not a record.

```
repo/
  brand-foundation.md          the one document; edit here, then rebuild
  projects/
    README-prompts.md          the five bare prompts with the marker
    01-content-strategist.instructions.txt
    02-researcher.instructions.txt
    03-product-builder.instructions.txt
    04-email-marketer.instructions.txt
    05-analyst.instructions.txt
  content/
    2026-09-21-week1.md        named by the Monday it posts
    2026-09-28-week2.md
  email/
    welcome-sequence.md
    2026-10-02-what-broke.md   named by send date and subject slug
  products/
    free-guide.md
    free-guide-v0.pdf
    playbook-v0.md
  numbers/
    weekly-numbers.txt         the same file uploaded to the Analyst
    2026-11-15-analyst.md      one per Sunday run
  tools/
    qa_check.py
    build_guide_pdf.py
  docs/
    00-setup-checklist.md
    employees.md
```

Rules:

1. Content files open with a BLUF block, then the posting schedule table, then one section per video. Part 6 has the template.
2. Every [ON SCREEN] cue stays in the script. It is the shot list for Wednesday.
3. Product drafts are versioned by filename. v0 is the first full draft. The number goes up when a section is added or a placeholder is filled, never for typo fixes.
4. Emails are one file each. The welcome sequence is the exception because it was written as a set.
5. The numbers folder does not exist until the first Analyst run. Do not create it empty. An empty folder is a promise you have not kept yet.

### 3.4 The git repo as the record

Bottom line: the folder above is a git repository. Every session ends with a commit. The history is the documentation I promised to keep from day one: every prompt edit, every Foundation change, every batch, with a date.

Why git and not a cloud folder: a cloud folder shows you the current file. Git shows you every version, what changed between them, and when. When a script stops sounding like me, I can find the Foundation edit that did it. When someone asks what the Brand Foundation said in September, the answer is in the history, not in my memory.

Setup, once:

1. Install git from git-scm.com. Defaults are fine.
2. Open a terminal in the repo folder.
3. git init
4. git add -A
5. git commit -m "day 1: foundation, five prompts, free guide v0"

Every session after:

1. git add -A
2. git commit -m "<what happened>"

Commit message convention, short and specific: "week2: scripts edited, gate ok". "foundation: retire 0 employees, add first hire (2027-01-10)". "email: welcome 3 sent". "playbook: v0 to v1, numbers section filled through Nov". The message is the changelog. Write it for the person reading it in six months, which is you.

Optional: push to a private repository on GitHub or a similar host so the record survives the laptop. Private. This repo holds your prices and your plans, not your client data, but it is still yours.

What never goes in the repo: client names, client data, screenshots with identifying detail from a security engagement, credentials, API keys, exported subscriber lists. The Analyst gets aggregate numbers only. If a file would hurt someone if the repo leaked, it does not go in.

[SCREEN RECORDING 06: git init through the first commit, then a second commit after a Tuesday batch, then git log showing both]

### 3.5 The gate in the loop

Bottom line: the gate runs before anything leaves the repo. Tuesday before filming, Thursday before versioning, Friday before sending.

The command, from the repo folder:

```
python3 tools/qa_check.py content/*.md email/*.md products/*.md
```

Exit 0 or it does not post. On a FAIL:

1. Read the problem lines. Each names the file, the word, and the count.
2. Open the file. Fix the copy. If the model wrote the line, feed the fixed line back to the Project with "write like this, not like that."
3. Re-run. Repeat until every file reads ok.
4. If the same banned word keeps coming back from the same Project, the Foundation is too vague on that point. Fix the Foundation, rebuild the five files, re-paste.

One more rule. The gate never gets a word removed from its list to make a file pass. Words get added. They do not get taken out because a sentence was hard to rewrite.

### 3.6 Scheduled reminders

Bottom line: the rhythm fails when it lives in your head. Put six recurring events in the calendar, one per day, and make the event description the exact thing to paste. Opening the reminder should mean the session has already started.

Set these up once, recurring weekly, at whatever hour you will keep:

Sunday. Title: Analyst. Description: "Copy numbers from YouTube Studio, TikTok Analytics, IG Insights, Kit. Open the Analyst. Paste with today's date and last Sunday's file. Save to numbers/. Update weekly-numbers.txt. Copy the priority line to next week's content file. Commit. (Skip until 20 posts.)"

Monday. Title: Researcher. Description: "Three best pieces from the weekend, hook and format and two lines each. Open the Researcher. Ask what they share and what to test. Create next week's content file. Paste priority and test under Inputs. Commit."

Tuesday. Title: Content Strategist. Description: "Open the Content Strategist. Paste Inputs and five topics. Get the batch. Edit until it is me. Gate. Commit."

Wednesday. Title: Outreach, then film. Description: "Security outreach out first. Then film all five. Cut. Post or schedule. Paste links into the content file. Commit. No AI today."

Thursday. Title: Product Builder. Description: "Open the Product Builder with the current product file. One section, one outline, or pricing. Version it. Gate. Commit."

Friday. Title: Email Marketer. Description: "Open the Email Marketer with this week's content file and the Thursday line. One email, one CTA, waitlist until launch. Gate. Send in Kit. Commit."

If your Claude plan offers scheduled tasks that can open a Project on a timer, they can replace the calendar for the AI days. Can't verify what your plan includes on the day you read this. Check claude.ai. The calendar version costs nothing and works on every plan, so it is the default in this playbook.

[SCREEN RECORDING 07: the six calendar events created, the Tuesday one opened, the description pasted into the Content Strategist]

### 3.7 Project knowledge files

Bottom line: each Project gets the same two files, and two Projects get one more.

Every Project:

- brand-foundation.md. Yes, it is already in the instructions. The file copy lets the Project quote it exactly and lets you check which version it holds.
- offers.txt. What you sell, with prices, one per line. Copy the WHAT I SELL block from the Foundation.

Product Builder only:

- The five .instructions.txt files. The Product Builder writes about the prompts. Without them in its knowledge it invents prompts that sound right and are wrong. The free guide was drafted with them loaded.

Analyst only:

- weekly-numbers.txt. Blank on day 1. Updated every Sunday. It is the Analyst's memory between sessions.

Remove from every Project: the packet PDF, if you uploaded it. Its last page contains the kind of vocabulary the gate bans, and an employee with that page in its context will drift toward it.

[SCREEN RECORDING 08: the knowledge panel of each Project, the files uploaded, the packet PDF removed from the Content Strategist]

---

## 6. Part 4: Screen recordings

Bottom line: one clip per build step, recorded on my real account, with real files. No staged dashboards. Client detail blurred. Each clip is short and does one thing.

Delivery: unlisted YouTube links inside the download, so they can be updated without re-issuing the file. [DELIVERY: confirm unlisted links versus embedded files before launch.]

| Clip | Shows | Lives in section |
|---|---|---|
| 01 | Intake prompt, first question, my first answer dictated | 2.2 |
| 02 | Raw summary next to edited Foundation, four passes applied | 2.4 |
| 03 | A Project refusing to invent a stat, saying "can't verify" | 2.5 |
| 04 | Gate run on a batch: one FAIL, the fix, the re-run | 2.7 |
| 05 | Rebuilding five instruction files after a Foundation edit, re-paste, confirmation test | 2.8 |
| 06 | git init, first commit, second commit, git log | 3.4 |
| 07 | Six calendar reminders created, one opened and used | 3.6 |
| 08 | Project knowledge files per Project, packet PDF removed | 3.7 |
| 09 | A full Tuesday: Inputs pasted, batch returned, one script edited to ok | 6.1 |
| 10 | A full Friday: content file in, one email out, sent in Kit | 3.2 |
| 11 | First Sunday with real numbers: paste, reply, priority line copied | 7 |

Clips 09 through 11 are recorded during the weeks they happen, not staged in advance. Clip 11 cannot exist until 20 posts exist. If it is missing at launch, the download says so on the page where it would sit.

---

## 7. Part 5: The real numbers

Bottom line: this section is empty. Nothing in it is a number yet. Each frame below names what goes in it, where it comes from, and when it can be filled. Until then the only numbers I will show anywhere are the ones in NUMBERS I CAN CITE.

I am not filling these with estimates, projections, or the packet's sample stats. An empty chapter is a worse sales page than a full one, and I am shipping v0 with it empty anyway, because a filled one would be a lie.

### 5.1 Posting

[DATA: posts published per week, by platform, from the first posting week onward. Source: the content files, links pasted in on Wednesdays. Fills weekly. First entry: the week of 2026-09-21 once the clips are posted.]

[DATA: longest gap between posts, in days, per month. Source: same. The goal is no gap over three days. Misses get listed, not hidden.]

### 5.2 Reach

[DATA: views per platform per week, best and worst clip with the hook that ran on each. Source: YouTube Studio, TikTok Analytics, IG Insights, pasted into the Sunday Analyst file. Fills from the first Analyst run, which is after 20 posts.]

[DATA: average watch percentage per platform, by week. Same source. Same timing.]

### 5.3 List

[DATA: subscribers from the free guide, by week, with the Kit dashboard date. Source: Kit. Fills from the week the form goes live.]

[DATA: open rate and click rate per Friday email, by send date. Source: Kit. Fills from the first broadcast.]

[DATA: waitlist sign-ups by week. Source: Kit waitlist tag. Fills from the day the form goes live. Closes at launch.]

### 5.4 Product

[DATA: playbook copies sold, by week, from launch day. Source: Stripe. Fills from launch.]

[DATA: refunds, by week. Same source. Listed, not hidden.]

### 5.5 Security pipeline

[DATA: qualified security leads that named a LinkedIn post as the reason for contact, by month. Source: my own outreach log, aggregate count only, no names. Fills monthly.]

### 5.6 What each Sunday said

[DATA: the "Your priority this week:" line from every Analyst run, in order, with the date. Source: numbers/. This is the one list that shows whether the Analyst was right, because the following week's numbers sit under it.]

When enough of these are filled to say something, the section gets rewritten as a read-out and the file becomes v1. The Not in this version list in section 11 says what "enough" means.

---

## 8. Part 6: The first four weeks as templates

Bottom line: one batch file per week, same structure every week, five topics, one per day, one CTA. Week 1 is written and lives in content/2026-09-21-week1.md. Its structure is the template. Weeks 2 through 4 below are the template filled with a theme, a pillar mix, and topic slots you hand to the Content Strategist on Tuesday.

### 6.1 The batch file structure (from Week 1)

Top of file:

- Title line: WEEK N CONTENT BATCH, with the Monday to Friday dates.
- BLUF: six numbered lines. How many clips, where they post, the single CTA and any one-time offer mention, the pillar mix, which clips carry a LinkedIn version and when those post, a line confirming every number is from the verified list, and the filming order grouped by format.
- Posting schedule table: day, date, clip title, pillar, LinkedIn post if any.
- Inputs block (added from Week 2 onward): the Analyst priority line and the Researcher test.

Then one section per clip, five per week, each containing:

- Header: clip number and title. One line under it with the pillar and the format (face on camera, screen recording, on-screen text).
- Hooks: three options.
- Script: timed in ten-second blocks from 0:00 to 0:50, each block opening with an [ON SCREEN] cue. First block is the bottom line. Last block is the CTA and nothing else.
- Caption: three short lines, the last one the CTA.
- Hashtags: seven.
- Alternative angle: one, in two or three sentences, that changes the format rather than the message.
- LinkedIn text version: only for pillar 2 and pillar 3 clips. Owner-to-owner. No veteran framing. Ends on a question. Three hashtags. Its post date is in the schedule table.

Production rules baked into the structure:

- Face-on-camera clips are grouped so they film in one sitting. Screen recordings are grouped and filmed after the thing on screen exists.
- The LinkedIn post for a security topic can go up a day before the clip. The audiences do not overlap.
- Every clip ends on the free guide. A paid offer gets named once, after the free CTA, and only on a pillar 2 clip where it fits.

[SCREEN RECORDING 09: a full Tuesday, Inputs pasted, the batch returned, one script edited until it reads like me and passes the gate]

### 6.2 Week 1: what it covered

Theme: day one. The five Projects exist and the audience sees them being set up.

Pillar mix: two AI-team clips, one security, one solo ops, one vet-to-owner. Two LinkedIn versions.

Formats: two screen recordings filmed after the Projects were built, three face-on-camera clips in one sitting.

The thing to copy from it is not the topics. It is that every clip made one claim from the verified list, named one mistake, and pointed at one link.

### 6.3 Week 2 template

Theme: what broke. Week 1 was the plan. Week 2 is the report. The audience was promised documentation, so the first thing they get after the setup is the first failure.

Pillar mix: two AI-team, one security, one solo ops, one vet-to-owner. Two LinkedIn versions (the security and the solo ops clip).

Topic slots to hand the Content Strategist:

1. AI-team, screen recording: the first output that sounded like a chatbot, the Foundation line I changed, the output after. Before and after on screen.
2. AI-team, screen recording: the gate script catching something in my own batch. The FAIL line on screen, the fix, the ok.
3. Security, face on camera: one of the four exposure categories from Week 1, in depth, with the fix in plain steps. LinkedIn version.
4. Solo ops, face on camera: the day this week I built instead of sent, and what the outreach rule did about it. LinkedIn version.
5. Vet-to-owner, face on camera: the after-action review as a weekly habit, with this week's three lines filled in on screen.

Inputs block: no Analyst line yet (under 20 posts). Researcher test from Monday.

### 6.4 Week 3 template

Theme: the hand-off. The audience has seen the Projects and seen one break. Now they see output move from one to the next.

Pillar mix: two AI-team, one security, one solo ops, one vet-to-owner. Two LinkedIn versions.

Topic slots:

1. AI-team, screen recording: Monday's Researcher reply becoming Tuesday's Inputs block becoming a script. Three windows, one clip.
2. AI-team, screen recording: the folder. content, email, products, and the git log with three weeks of commits. What a record looks like.
3. Security, face on camera: the email authentication check. What a missing record lets a stranger do, and the fix. Name the offer once, after the free CTA. LinkedIn version.
4. Solo ops, face on camera: pricing. Why the prices are in the Foundation and what happened the last time I quoted one from memory. LinkedIn version.
5. Vet-to-owner, face on camera: nobody is coming with a task list. What a Sunday looks like when you are the one writing the orders.

Inputs block: Researcher test. Analyst line if 20 posts exist by then, otherwise "no Analyst run yet" written in the block so the gap is visible.

### 6.5 Week 4 template

Theme: month one, after action. What was supposed to happen, what happened, what changes. The first honest scoreboard, even if the score is small.

Pillar mix: two AI-team, one security, one solo ops, one vet-to-owner. Two LinkedIn versions.

Topic slots:

1. AI-team, screen recording: the first real Sunday. Numbers pasted in, the Analyst reply, the priority line. If the run has not happened, the clip is the reason why and the date it will.
2. AI-team, face on camera: what the AI team did not do this month. The list of things I still did by hand.
3. Security, face on camera: staff posting rules. What the people who work for you put online and who reads it. LinkedIn version.
4. Solo ops, face on camera: the four-week count. Posts planned versus posted, outreach planned versus sent. The numbers on screen, whatever they are. LinkedIn version, owner-to-owner, same count.
5. Vet-to-owner, face on camera: one habit from the four the audience should keep, one they should drop, said plainly, no list.

Inputs block: Analyst line, if it exists. Researcher test.

After Week 4, the template holds and the themes come from the Analyst. That is the point of the first month: get to the Sunday where the numbers pick the topics.

---

## 9. Name options

Bottom line: option 1 is the working title and it stays unless something below beats it in the waitlist emails. Each name pairs with the free guide's title so the buyer knows it is the next step, not a different product.

1. The Solo Operator's AI Team: Playbook
Subtitle: The method, the hand-offs, the gate, and my numbers as they come in.

2. Staff of None
Subtitle: Five Claude Projects, one owner, and the conventions that turn chat output into posts.

3. The $20 Marketing Department
Subtitle: What I built on top of five free prompts so they ship every week without me.

4. Zero Employees, Five Projects
Subtitle: The Brand Foundation method, the weekly hand-off, and the script that keeps it honest.

5. Documented As I Go
Subtitle: The paid half of the free guide: automations, recordings, and real numbers with dates.

Option 1 wins on continuity. Option 3 wins on the hook and cites a verified number. Test both as subject lines to the waitlist before launch and pick by replies, not by open rate. [DATA: waitlist subject line test, replies per option, date.]

---

## 10. Price

Bottom line: $37.

1. What is included: the full Brand Foundation method with a worked example, the hand-off map and checklist, the file conventions, the git setup, the gate script, six calendar reminders written out, eleven screen recordings, four weeks of batch templates, and the numbers section filled as data arrives, with updates pushed to buyers.
2. What the free guide already gives away: the five prompts, the marker, the six questions in short form, the weekly schedule, and the failure list. A buyer who wants only that should not pay anything, and the sales page will say so.
3. Why not $27: the bottom of the range reads as a prompt pack, and the free guide already is one. The work in this playbook is the recordings and the script, and pricing them at the floor undercuts the thing that makes it different from the packet.
4. Why not $47: the numbers chapter is empty in v0. Charging the top of the range for a book with an empty chapter is not defensible, and I would not pay it. $47 is the v1 price, when Part 5 has real entries and the buyer is paying for something I can show.
5. Why $37 and not something between: it is the number I can say on camera without a caveat, and v0 buyers get v1 at no charge, so the early price is the discount for buying the empty chapter on trust.

No conversion assumptions went into this. The sales goal in the Foundation is a target with a date, not an input to the price.

---

## 11. Not in this version

Bottom line: v1 ships when the Analyst has 8 weeks of Sunday runs in numbers/. Here is what it adds.

1. Part 5 rewritten as a read-out: the frames filled, dated, with the best and worst week and what changed between them.
2. Screen recording 11 and any clip that could not be recorded before launch.
3. A numbers whitelist in the gate. The script reads NUMBERS I CAN CITE from the Foundation and flags any digit string in a content file that is not on it. Prices and dates get an allow rule.
4. The Foundation changelog: every edit to brand-foundation.md in the first 8 weeks, from git log, with the output problem that caused each one.
5. The Analyst's track record: each Sunday's priority line next to the following week's numbers, so the buyer can see whether the advice held up.
6. Kit automation notes once the list is on a paid plan: the welcome sequence as a true drip, and what changed in the numbers when it moved.
7. A section on the outreach rule with the count: security outreach sent per week against posts filmed per week, for 8 weeks. If the rule failed, that goes in.
8. Local AI. Pillar 1 promises it. Nothing about it exists in the repo yet, so nothing about it is in v0. When a local model does one of the five jobs in the actual weekly loop, it gets a section. Not before.
9. Subject line test results from section 9, and the name change if there is one.
10. Whatever the first ten buyers reply with. The email 5 reply ask stays open after launch, and the first ten replies decide the first added section that is not on this list.

v0 buyers get v1 at no charge. Say that on the sales page.

---

## 12. Credit

Bottom line: the five prompts are Jianna Capri's. Buy nothing to get them.

The five employee prompts referenced throughout this playbook, and printed in full in the free guide, come from the free packet "Your $20 AI Content Team" by Jianna Capri. Her terms: share freely, credit kindly. Get the original here: [CAPRI PACKET LINK]. I did not write the prompts. I adapted one line in the Analyst prompt and added a marker to each. Her intake prompt and her six questions are the basis for Part 2 as well.

What the buyer is paying for is what I added on top: the Brand Foundation method in full with my own document as the example, the NUMBERS I CAN CITE rule and the banned-word method, the QA gate script, the hand-off conventions and the git record, the screen recordings of every build step on my real account, the four batch templates, and the numbers section as it fills with dated data from my own businesses. None of that is in her packet. All of her packet is free.

If you share this playbook, share it whole and keep her credit on it. If you share the prompts on their own, credit her, not me.

Josh Henry
Henry Intel, Throttle Logic, Deadbolt Dynamics
