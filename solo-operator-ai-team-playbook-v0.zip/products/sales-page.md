# Sales page: The Solo Operator's AI Team: Playbook

Copy v0. Written 2026-09-15 in the Product Builder slot. Pre-launch state: the call to action is the waitlist. On launch day, swap every [WAITLIST LINK] for the Stripe Payment Link and delete the pre-launch note block. Nothing else on the page changes.

Every number on this page is from NUMBERS I CAN CITE plus the $37 price. Counts of what is inside the download (recordings, templates, reminders) describe the product, not results.

---

## Headline

The Solo Operator's AI Team: Playbook

Subhead: Five Claude Projects do my marketing for $20/month. The prompts are free. This is what I built on top so the output ships every week.

Alternate headline for the waitlist test (playbook section 9): The $20 Marketing Department. Pick by replies, not opens.

---

## Opening block

Bottom line: the five prompts cost nothing. Jianna Capri wrote them and gave them away. The free guide shows you how to set them up in under an hour. This playbook is the part that comes after the setup: the method that makes them sound like you, the hand-offs that move output from one Project to the next, the script that stops bad copy from shipping, and my own numbers with dates as they come in.

If you built the five Projects and good output is sitting in a chat window, this is for you.

If you have not built them yet, go get the free guide first. It is the whole method. Come back when something is stuck.

---

## Who wrote this

Josh Henry. 8 years Army. 3 businesses. 0 employees.

I pay $20/month for Claude Pro and nothing else for marketing. I have 1 security client. I have no content numbers I can cite yet. Everything the five Projects produce for my businesses goes on video as it happens, and into this playbook with the date.

That is the whole track record. Read the rest of this page with that in mind.

---

## What is inside

1. The Brand Foundation method in full. The intake prompt, the six questions with my answers as the worked example, the four-pass edit from voice dump to document, the NUMBERS I CAN CITE rule, and the banned-word method. This is the document that does more work than all five prompts combined.

2. The QA gate. One Python file, one command. It fails any file with a banned word, an em dash, an exclamation point, or an emoji before it ships. Explained line by line, with the rule for what it cannot catch and what you check by hand.

3. The hand-off between the five Projects. The day-by-day map, the weekly checklist, the file conventions, the git setup that makes the folder the record, and six calendar reminders written out so opening one starts the session.

4. Screen recordings of every build step, on my real account, with real files. No staged dashboards. Eleven clips, indexed to the section each one belongs to. Any clip not recorded by launch is listed as missing on the page where it would sit.

5. The real numbers and the first four weeks of content. Posting, reach, list, sales, and security pipeline, each with the source and the date, filled as the data arrives and pushed to buyers. Plus four batch templates: the structure I hand the Content Strategist every Tuesday, with a theme and five topic slots per week.

---

## What is free somewhere else

Do not pay for these. They are already yours.

The five employee prompts: in Jianna Capri's free packet, "Your $20 AI Content Team." Link in the credit section below.

The setup, the [BRAND FOUNDATION] marker, the six questions in short form, the weekly schedule, and the five ways it breaks: in my free guide. Link in bio.

If the prompts and the setup are all you want, close this page. You have everything you need and it cost you nothing.

---

## What this is not

It does not film, post, or sell. You do that.

It does not promise income. I have 1 client and I will say so on every page.

It does not contain other people's statistics. If a number is not from my own accounts with a date on it, it is not in here.

It does not fix a bad offer. If nobody wants the thing you sell, five Projects will describe it very well to nobody.

---

## Price

$37.

Why not less: the free guide already covers the prompts. What you are paying for is the recordings, the gate, and the method with a worked example, and pricing that at the floor says it is a prompt pack. It is not.

Why not more: the numbers chapter is empty at launch. I am not charging full price for a book with an empty chapter.

What that gets you: every version after this one at no charge. When the numbers chapter is filled and the price goes up, you already have it.

[REFUND POLICY: Josh decides. Recommended default: refund on request within 30 days, no questions, stated in one line here.]

---

## Credit

The five prompts referenced in this playbook, and printed in full in the free guide, come from the free packet "Your $20 AI Content Team" by Jianna Capri. Her terms: share freely, credit kindly. Get the original here: [CAPRI PACKET LINK]. I did not write the prompts. Everything you are paying for is what I added on top, and all of her packet is free.

---

## Call to action

Pre-launch:

The playbook is not built yet. There is nothing to buy today. Join the waitlist and you get one email when it ships, at $37, with everything above in it. Until then, the free guide is the full method.

Join the waitlist: [WAITLIST LINK]

Launch day (replace the block above with this):

Get the playbook: $37. [STRIPE PAYMENT LINK]

Every future version included.

---

## Page notes for Josh

1. Above the fold: headline, subhead, the three lines under Who wrote this, and the button. Everything else scrolls.
2. One button. Same link everywhere it appears on the page.
3. No testimonials block. There are no buyers. Do not add one until there are, and then only with permission and names.
4. The refund line and the two links are the only holes. Fill them and this page can go live on the waitlist tool the same day.
5. Run tools/qa_check.py on this file after every edit. It passed on 2026-09-15.
