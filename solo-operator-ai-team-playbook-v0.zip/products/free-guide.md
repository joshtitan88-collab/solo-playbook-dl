# The Solo Operator's AI Team

## 5 Claude Projects that replace a marketing staff, built in an hour, documented as I go

By Josh Henry

---

## 1. Bottom line

This is a build guide for five Claude Projects that do the marketing work a small staff would do: strategy, research, product drafting, email, and analytics.

I pay $20/month for Claude Pro. Nothing else.

It writes, researches, outlines, drafts, and reads your numbers. It does not film, it does not post, it does not sell, and it does not fix a bad offer.

It is for the person running a business alone who has no marketing help and no budget to hire any.

Setup takes under an hour. This guide is the setup, the prompts, the weekly schedule, and the ways it breaks.

---

## 2. Who wrote this and why you should not take my word for it

Josh Henry. 8 years Army: 1st Ranger Battalion, 101st Airborne, 3rd ID. Georgia.

I own three businesses: Henry Intel (OSINT and cybersecurity), Throttle Logic (Harley EFI tuning), Deadbolt Dynamics (locksmith).

I have 0 employees.

I am building an AI team to do the marketing a staff would do, and documenting it from the first day: the setup, the numbers, the mistakes.

The security side sells three things: an Email Authentication Fix at $850 one-time plus $150/month monitoring, an Exposure Audit at $497, and Exposure Monitoring at $497, $747, or $997 per month by business size.

I have one security client so far. That is the whole track record.

Here is the full list of numbers I will cite, verbatim from my own brand document:

- 8 years Army. 3 businesses. 0 employees.
- $20/month: the entire cost of the AI team.
- 5 Projects, set up in under an hour.
- 1 healthcare-practice security client, anonymized; first engagement paid $2,000+.
- The offer prices above.

That is it. No subscriber count, no revenue screenshot, no views number, because I do not have ones I can stand behind yet. Whatever this AI team produces for my business, I will show on video as it happens. Watch the videos and check. If it is not in the list above, treat it as unverified.

---

## 3. The 60-minute build

Bottom line: one Claude Project per employee, five Projects total, each with its own instructions. Projects are available on the Free plan at the time of writing, with usage limits that will stop you mid-session. I run it on Pro at $20/month. Verify current plans and pricing at claude.ai before you start.

Do the Brand Foundation (section 4) before you build the Projects. The Projects are useless without it. Clock times below are targets. If you are slower, nothing breaks.

### Minutes 0 to 5: account

1. Go to claude.ai and sign in.
2. Free plan works to build. Upgrade to Pro ($20/month) when the usage limit interrupts a session.
3. Confirm you see "Projects" in the left sidebar.

[SCREENSHOT: claude.ai left sidebar with Projects visible]

### Minutes 5 to 15: Project 1, Content Strategist

1. Click "Projects" in the left sidebar.
2. Click "New project" (top right).
3. Name it "Content Strategist". Leave the description blank or write one line. Click "Create project".
4. On the project page, find the instructions panel. It is labeled "Set project instructions" or "Instructions" depending on the current layout.
5. Paste the Content Strategist prompt from section 5. Where the prompt says [BRAND FOUNDATION], delete that marker and paste your full Brand Foundation in its place.
6. Save.
7. Start a chat inside the project and type: "Confirm you have my Brand Foundation. Quote my audience back to me in one line." If it quotes you correctly, the instructions are loaded.

[SCREENSHOT: New project dialog with the name field filled in]

[SCREENSHOT: Instructions panel with prompt pasted and Brand Foundation inserted]

### Minutes 15 to 45: Projects 2 through 5

Repeat the exact steps above four more times. One Project each:

- "Researcher"
- "Product Builder"
- "Email Marketer"
- "Analyst"

Same steps. Same Brand Foundation pasted in at the marker. Same confirmation test.

Do not build one giant Project with all five prompts inside it. Each employee has a different job and output format. Mixing them makes every answer worse.

### Minutes 45 to 55: knowledge files

Each Project has a place to add files (labeled "Project knowledge" or similar). Add to every Project: your Brand Foundation as a text file, and a file called "offers.txt" listing what you sell with prices. Add to the Analyst only: a blank "weekly-numbers.txt" you will update every Sunday.

[SCREENSHOT: Project knowledge panel with files uploaded]

### Minutes 55 to 60: first run

Open the Content Strategist. Give it a real topic you would post this week. If the output sounds like a marketing department, your Brand Foundation is too vague. Go back to section 4 and sharpen HOW I TALK. If it sounds like you, the build is done.

---

## 4. The Brand Foundation: the document that makes it sound like you

Bottom line: the Brand Foundation is a one-page document that tells every Project who you are, who you are talking to, what you sell, and how you talk. Without it, the five prompts produce generic content. With it, they produce yours.

### The method

Open a regular Claude chat. Not a Project. Paste this:

> I need your help figuring out what I am building so I can set up my AI team. Ask me questions one at a time about: what I create content about, who my audience is (be specific), what platforms I post on, what I am selling or want to sell, what my content goals are for the next 6 months, and how I talk (my tone, my vibe, words I use or avoid). After I answer everything, write me a short Brand Foundation summary I can paste into other AI prompts. Keep it clear and specific. Start with the first question now.

Then answer six questions, one at a time. Voice dump if you want. Do not polish. Claude will polish.

### The six questions

1. What do you create content about? Name three or four pillars, not one vague theme.
2. Who is your audience? Age range, situation, what they hate, what they trust. "Small business owners" is not an answer. "Veterans 28 to 45 who want to own something instead of taking a W-2 and will not sit through mindset content" is an answer.
3. What platforms do you post on, and in what format?
4. What do you sell, or what do you want to sell? Prices included.
5. What are your content goals for the next six months? Numbers, with dates.
6. How do you talk? Sentence length, tone, words you use, words you never use.

When it hands you the summary, read every line. Cut anything that is not true. Then add the section most people skip.

### The section most people skip: numbers I can cite

Add a heading to your Brand Foundation that says NUMBERS I CAN CITE. Under it, list only the numbers you can prove today. Then add one line: "Anything else: say can't verify or leave it out."

This is the key move. Every AI writing tool will invent a statistic if you let it. It sounds right, it gets pasted into a caption, and now you are the one lying. A short verified list, plus an explicit instruction to invent nothing, is the fix. The model is told what it may say and what to do when it does not know.

### Worked example: mine

Lines from my own Brand Foundation, so you can see the level of detail that works.

From WHO IT IS FOR:

> Primary audience (short-form video): veterans and transitioning service members, 28 to 45, who want to own something instead of taking a W-2.

> They will not tolerate fluff, cheerleading, or mindset content with no steps. They trust someone who shows the actual screen and the actual number.

From NUMBERS I CAN CITE:

> 8 years Army. 3 businesses. 0 employees.

> $20/month: the entire cost of the AI team.

> Anything else: say "can't verify" or leave it out. No other client stories exist yet.

From HOW I TALK:

> BLUF is structure, not a spoken word: bottom line first, always. Short sentences. Blunt, directive, peer-to-peer.

> Military framing without tacticool cosplay: no skulls, no warrior theatrics.

> Say the number (from the list above). Name the mistake. Show the screen.

> On facts I cannot verify, say "can't verify" instead of softening.

> Never fabricate results, numbers, or client stories.

No mission statement. No "brand values." Just what I talk about, who is listening, what I sell, what I can prove, and how I sound. One page. Paste it into every Project at the [BRAND FOUNDATION] marker.

---

## 5. The 5 employees

Bottom line: five prompts, five jobs. Each prompt goes into the instructions of its own Project with your Brand Foundation pasted in at the marker. The base prompts are from Jianna Capri's free packet (credit in section 9). The marker and the method are what I added.

### 5.1 Content Strategist

What it does: turns a topic into a script or caption in your voice, with hooks, hashtags, and a second angle.

The prompt:

```
You are my Content Strategist. Write content that sounds exactly like me.
[BRAND FOUNDATION]
Every time I give you a topic:
1. Give me 3 hook options
2. Write the full script or caption
3. Suggest hashtags
4. Offer one alternative angle
Short sentences. My voice. No fluff.
```

First task: give it the one topic you could talk about with no notes. Mark every line in the script you would never say. Feed those lines back and say "never write like this."

Mistake to avoid: a topic with no context. "Write about AI for small business" gets you a listicle. "Write about the morning I lost rebuilding a prompt instead of posting the video I already filmed" gets you a script.

### 5.2 Researcher

What it does: breaks down content that is working in your niche and tells you what to steal, what to test, and what to do next.

The prompt:

```
You are my Content Researcher. Help me understand what is working in my niche and why.
[BRAND FOUNDATION]
When I share content or describe what I see:
1. Break down why it worked (format, hook, topic, pacing)
2. Tell me how I can apply it to my content
3. Flag anything worth testing
End every analysis with one specific next move. Be direct. Skip the fluff.
```

First task: pick three videos from your niche you saw this week and thought were good. Paste in the hook, the format, and two lines describing each. Ask what they have in common.

Mistake to avoid: asking it what is trending. It cannot see your feed. You are the eyes. It is the analysis.

### 5.3 Product Builder

What it does: takes a product idea and gives you a market check, an outline, draft content, names, and a price.

The prompt:

```
You are my Product Builder. When I give you a product idea, help me build it from scratch.
[BRAND FOUNDATION]
For every product idea:
1. Tell me if there is a real market for it and who buys it
2. Create a full outline with sections
3. Write the actual content for each section
4. Suggest 5 name options with a subtitle
5. Recommend a price point and explain why
Practical language. Steps, not theory. Clear takeaways.
```

First task: describe the one thing people already ask you how to do. Ask it to build a short guide around that. This guide was drafted that way.

Mistake to avoid: building the thing you find interesting instead of the thing your audience asks for. It will happily outline a course nobody wants.

### 5.4 Email Marketer

What it does: writes emails that read like a person wrote them, with subject line options and one call to action.

The prompt:

```
You are my Email Marketer.
Write emails that sound like a real person. Warm, direct, worth reading.
[BRAND FOUNDATION]
For every email include:
- Subject line plus 2 alternatives to test
- Preview text
- Full email body
- One clear call to action
Short paragraphs. One CTA per email only. No corporate language.
```

First task: the welcome email. Tell it what the reader downloaded, what you want them to do next, and one thing to know about you. One email, not a sequence.

Mistake to avoid: a call to action pointed at a product that does not exist yet. If your paid thing is not built, the CTA is the waitlist or a reply.

### 5.5 Analyst

What it does: reads your numbers and tells you what changed, what is working, what to fix, and one action for the week.

The prompt:

```
You are my Analytics Advisor. Give me the numbers straight: rates, deltas, and what changed. Explain what my stats mean in plain language and tell me exactly what to do.
[BRAND FOUNDATION]
When I share data:
1. Summarize what the numbers are telling me
2. Top 2 or 3 things working well
3. Top 2 or 3 things to fix
4. One specific action to take this week
5. Flag anything surprising
End every response with: "Your priority this week:" and one clear task.
```

First task: paste in last week's platform stats exactly as the dashboard shows them. If you have nothing yet, paste in zeros with the date. That is your baseline.

Mistake to avoid: numbers with no dates and no prior week. It can only measure change from two points in time. One number is not data.

---

## 6. The weekly rhythm

Bottom line: one employee per day, one day with no AI at all. The AI does the thinking work on the days around the filming. You do the filming.

**Sunday: Analyst.** Paste in the week's numbers. Get the priority for the week. Update the weekly-numbers.txt file in the Analyst's Project knowledge.

**Monday: Researcher.** Bring it the three best pieces of content you saw in your niche over the weekend. Get the pattern and the one test to try.

**Tuesday: Content Strategist.** Give it the week's topics, informed by Sunday's priority and Monday's test. Get the scripts. Edit them until they sound like you.

**Wednesday: film and post. No AI.** Camera or screen recording. Cut it. Post it. This is the only day that produces anything the audience sees. Every other day exists to make this day faster.

**Thursday: Product Builder.** One session on whatever you are building for sale. Outline, section draft, or pricing. Ship a piece of it.

**Friday: Email Marketer.** One email to the list. What you posted, what you learned, what is next.

Then the one rule: they perform exactly as well as the context you give them.

The Analyst with no numbers gives you guesses. The Researcher with no examples gives you generic advice. The Content Strategist with a vague topic gives you a vague script. That is the tool working as designed. Your job is to bring the context. Their job is to process it.

---

## 7. What will go wrong

Bottom line: the tool does not fail. You do, in predictable ways. Here are the five I have hit or watched others hit.

### 7.1 Building instead of shipping

You will want to tune the prompts one more time. Add one more file. Test one more Project. This feels like work and produces nothing the audience sees. If the prompts produce a script you can edit, stop tuning and film.

### 7.2 Letting AI write in its own voice

The default voice of every AI tool is a friendly marketing department. It drifts there whenever your Brand Foundation gets vague. Symptoms: "In today's fast-paced world," lists of three adjectives, a cheerful closer. The fix is HOW I TALK, written with more specifics than feels reasonable. Then edit every output before it goes out. The AI drafts. You publish.

### 7.3 Using the packet's sample stats

The free packet these prompts come from includes example numbers to show the format. They are not your numbers. Paste them into the Analyst and it will hand you a confident plan built on someone else's business. Delete every number you did not measure yourself.

### 7.4 Skipping Wednesday

Five days of AI sessions feel productive. One day on camera feels exposed. So Wednesday slips, and the week produced five documents and zero posts. Film first if you have to. Wednesday is the day the whole schedule serves.

### 7.5 Fabricated numbers

Covered in section 4 and repeated because it is the one that costs you trust. "Studies show." "Most creators see." No study. No creators. If it is not in your NUMBERS I CAN CITE list, it does not go in the post. Tempted to cite a result you have not had yet? Write "can't verify yet" or cut it. I have one client and one setup time I can prove. That is what you will hear me cite until the next verified number exists.

---

## 8. What is next

The paid playbook is coming. It adds what this guide does not: the automations that move output between Projects, screen recordings of every build step, and the real numbers from my own accounts as they come in, with dates. Price will be $27 to $47. It is not built yet, so there is nothing to buy today. There is a waitlist: [WAITLIST LINK]. Until it ships, this free guide is the full method. Build the five Projects, do the Brand Foundation, keep Wednesday, and I will show my numbers as I get them.

---

## 9. Credit

The five base prompts in section 5 come from the free packet "Your $20 AI Content Team" by Jianna Capri. Her terms: share freely, credit kindly. Get the original here: [CAPRI PACKET LINK].

What I added is the Brand Foundation method, the [BRAND FOUNDATION] insertion marker, the NUMBERS I CAN CITE rule, the weekly schedule, and the failure list. If you share this guide, share it whole and keep her credit on it.

Josh Henry
Henry Intel, Throttle Logic, Deadbolt Dynamics
