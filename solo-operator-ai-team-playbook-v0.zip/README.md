# The Solo Operator's AI Team

5 Claude Projects that replace a marketing staff. $20/month. Built in under an hour. Documented as it runs.

Base prompts: "Your $20 AI Content Team" by Jianna Capri (free packet; share freely, credit kindly). Everything else here is what was added on top: the Brand Foundation method, the QA gate, and the weekly production output.

## Layout

| Path | What |
|---|---|
| `brand-foundation.md` | The one document pasted into every Project. Edit here, then rebuild the 5 instructions files. |
| `projects/*.instructions.txt` | Paste-ready Project Instructions, one per employee, Foundation already inserted. |
| `projects/README-prompts.md` | The bare prompts with the `[BRAND FOUNDATION]` marker. |
| `docs/00-setup-checklist.md` | Setup steps, decisions made, weekly rhythm, Hidden Trap. |
| `docs/employees.md` | Per-employee first task, packet example, status. |
| `content/` | Weekly video/LinkedIn batches. One file per week, named by the Monday it posts. |
| `products/` | Free guide (md + PDF). Paid playbook goes here when built. |
| `email/` | Welcome sequence and later broadcasts. |
| `tools/qa_check.py` | Voice gate: banned words, em dashes, exclamation points, emojis, restricted-word cap. Run before anything ships. |
| `tools/build_guide_pdf.py` | Renders the free guide to PDF. |

## Weekly rhythm

Sun Analyst (after 20 posts) / Mon Researcher / Tue Content Strategist / Wed film and post, no AI / Thu Product Builder / Fri Email Marketer.

## Ship gate

```
python3 tools/qa_check.py content/*.md email/*.md products/*.md
```

Exit 0 or it does not post.

## Status (2026-09-17)

- Week 1 batch written (`content/2026-09-21-week1.md`): 5 videos Sep 21 to 25, 2 LinkedIn posts.
- Free guide v0 written and rendered. `[SCREENSHOT]` placeholders remain until the 5 Projects exist.
- Welcome sequence written for Kit Free (broadcast model).
- Researcher run for Week 2 written (`content/2026-09-21-research.md`): 4 lanes, 5 ranked tests, 6 topic candidates.
- Paid playbook v0 drafted (`products/playbook-v0.md`, 8,500 words, numbers chapter deliberately empty, price call $37).
- Sales page copy v0 written (`products/sales-page.md`): $37, waitlist CTA until launch, holes are the refund line and the two links.
- Stripe Payment Link copy v0 written (`products/stripe-product.md`, 2026-09-17): product name, checkout description, descriptor, link settings, delivery plan, launch-day order. Holes: refund line, download page URL, Stripe account name.
- Playbook stays at v0. No `numbers/` folder, no posted links, no screenshots in the repo, so no `[DATA]` or `[SCREENSHOT]` frame could be filled.
- Not done: the 5 Projects on claude.ai, the Kit form, the link in bio, the refund line. Every CTA points at those.
