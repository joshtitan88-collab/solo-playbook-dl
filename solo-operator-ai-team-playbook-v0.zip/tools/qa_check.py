#!/usr/bin/env python3
"""Brand Foundation QA gate. Run on any content file before it ships.
Exit 1 on any banned vocabulary, em dash, exclamation point, emoji, or restricted-word overuse.
Usage: python3 tools/qa_check.py content/*.md email/*.md products/*.md
"""
import re, sys

BANNED = ['delve','tapestry','robust','seamless','game-changer','game changer','unlock','journey',
          'great question',"it's important to note",'i hope this helps','wealth transfer','life-changing',
          'empower','elevate','transform','level up','crush it','grind','hustle','supercharge','leverage',
          'warrior','battle','brother','excited','thrilled']
RESTRICTED = ['operator','run it','systems','the actual steps']   # max 1 per piece, product names excluded
PRODUCT_NAME = "the solo operator's ai team"

def check(path):
    raw = open(path, encoding='utf-8').read()
    raw = re.sub(r'```.*?```', '', raw, flags=re.S)   # fenced code is not copy
    # blockquotes are quoted source text (e.g. Brand Foundation excerpts), not new copy
    s = '\n'.join(l for l in raw.splitlines() if not l.lstrip().startswith('>'))
    low = s.lower().replace(PRODUCT_NAME, '')
    problems = []
    if '\u2014' in s or '\u2013' in s: problems.append('em/en dash')
    if '!' in s: problems.append('exclamation point')
    if any(ord(c) > 0x2000 and c not in '\u2014\u2013\u2018\u2019\u201c\u201d' for c in s): problems.append('emoji/non-text glyph')
    for b in BANNED:
        n = len(re.findall(r'\b' + re.escape(b) + r'\b', low))
        if n: problems.append(f'banned "{b}" x{n}')
    # restricted words: count per section split on level-2 headers
    for sec in re.split(r'^## ', low, flags=re.M):
        hits = sum(len(re.findall(r'\b' + re.escape(w) + r'\b', sec)) for w in RESTRICTED)
        if hits > 1:
            problems.append(f'restricted words x{hits} in one section ("{sec[:40].strip()}...")')
    return problems

if __name__ == '__main__':
    bad = 0
    for p in sys.argv[1:]:
        probs = check(p)
        print(('FAIL ' if probs else 'ok   ') + p)
        for x in probs: print('     -', x)
        bad += bool(probs)
    sys.exit(1 if bad else 0)
