#!/usr/bin/env python3
"""Render products/free-guide.md to products/free-guide-v0.pdf with headless Chromium.
Requires: pip install markdown ; a Chromium binary on PATH or CHROMIUM env var.
"""
import markdown, os, subprocess, pathlib
root = pathlib.Path(__file__).resolve().parents[1]
src = root / 'products' / 'free-guide.md'
html_path = root / 'products' / 'free-guide.html'
pdf_path = root / 'products' / 'free-guide-v0.pdf'
css = """
@page{size:Letter;margin:0.9in}
body{font-family:Georgia,'Times New Roman',serif;font-size:11.5pt;line-height:1.45;color:#111;max-width:7in}
h1{font-family:Helvetica,Arial,sans-serif;font-size:26pt;margin:0 0 4pt}
h2{font-family:Helvetica,Arial,sans-serif;font-size:15pt;margin:26pt 0 8pt;border-bottom:1.5px solid #111;padding-bottom:3pt}
h3{font-family:Helvetica,Arial,sans-serif;font-size:12pt;margin:16pt 0 6pt}
p{margin:0 0 9pt}
pre{background:#f2f2f2;border-left:3px solid #111;padding:8pt 10pt;font-size:9.5pt;white-space:pre-wrap;font-family:Menlo,Consolas,monospace;page-break-inside:avoid}
blockquote{margin:0 0 9pt 14pt;padding-left:10pt;border-left:2px solid #999;color:#333}
hr{border:0;border-top:1px solid #bbb;margin:18pt 0}
ol,ul{margin:0 0 9pt 20pt} li{margin-bottom:3pt}
"""
body = markdown.markdown(src.read_text(), extensions=['fenced_code', 'tables'])
html_path.write_text(f"<!doctype html><html><head><meta charset='utf-8'><style>{css}</style></head><body>{body}</body></html>")
chromium = os.environ.get('CHROMIUM', 'chromium')
subprocess.run([chromium, '--headless', '--disable-gpu', '--no-sandbox', '--no-pdf-header-footer',
                f'--print-to-pdf={pdf_path}', str(html_path)], check=True)
html_path.unlink()
print('wrote', pdf_path)
